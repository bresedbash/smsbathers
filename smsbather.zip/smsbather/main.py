import sys, os, time
import core.sms 
from core.colors import FG
from termcolor import colored 

os.system('cls' if os.name == 'nt' else 'clear')

print(f'''
{FG.red}   
                                          _           _   _               
 ___ _ __ ___  ___| |__   __ _| |_| |__   ___ _ __ 
/ __| '_ ` _ \/ __| '_ \ / _` | __| '_ \ / _ \ '__|
\__ \ | | | | \__ \ |_) | (_| | |_| | | |  __/ |   
|___/_| |_| |_|___/_.__/ \__,_|\__|_| |_|\___|_|   
                                                                                                          
	''')     

showMenu = True
while showMenu:
    print(f'''
__________________________________________________
|¦ {FG.red} >>>> МЕНЮ ФУНКЦИЙ :{FG.blue}      ¦|
|¦ {FG.green}[ 1 ] sms-bomber{FG.blue}                ¦|
|¦                                                                                ¦|
|¦_________________________________________________¦|
''')

    cmd = input(colored("[~] > select option : ","red"))

    if cmd == "1":
        showMenu = False
        core.sms.menu()
    elif cmd == "0":
        showMenu = False
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"{FG.blue}Have a nice day, goodbye.{FG.blue}")
        time.sleep(2)
        sys.exit()
    else:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(colored("[!] Error.","red"))
